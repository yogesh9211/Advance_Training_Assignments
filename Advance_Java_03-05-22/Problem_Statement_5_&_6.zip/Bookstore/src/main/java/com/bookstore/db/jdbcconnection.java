package com.bookstore.db;

import java.sql.DriverManager;
import java.sql.SQLException;

import org.eclipse.jdt.internal.compiler.ast.ReturnStatement;

import com.mysql.jdbc.Connection;

public class jdbcconnection {
	private static Connection connection;

	public jdbcconnection(String dbURL, String userId, String pwd) throws ClassNotFoundException, SQLException {

		Class.forName("com.mysql.jdbc.Driver");

	this.connection=(Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/shoppingcart","root","Yogesh@9211");
	}

	public static Connection getConnection() {
		return connection;
	}

	public void closeConnection()   {
		if (this.connection != null) {
			try {
				this.connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
}
