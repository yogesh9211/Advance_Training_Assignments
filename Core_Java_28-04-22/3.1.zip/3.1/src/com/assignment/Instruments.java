package com.assignment;

public abstract class Instruments {

	public abstract void play();
}
