package com.assignment;

public class Guitar extends Instruments {

	public void play() {
		System.out.println("Guitar is playing  tin  tin  tin");

	}

}
