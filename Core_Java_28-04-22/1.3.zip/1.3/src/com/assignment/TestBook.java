package com.assignment;

import java.util.Scanner;

public class TestBook {

	public static void main (String[] args) {
        Scanner sc=new Scanner(System.in);
        
        System.out.println("Enter the Book name:");
        String bookname=sc.nextLine();
        
        System.out.println("Enter the price:");
        int price=sc.nextInt();
        sc.nextLine();
        
        System.out.println("Enter the Book name:");
        String bookname1=sc.nextLine();
        
        System.out.println("Enter the price:");
        int price1=sc.nextInt();
        sc.nextLine();
        
        
        Book obj=new Book();
        obj.setBookName(bookname);
        obj.setBookPrice(price);
        obj.setBookName1(bookname1);
        obj.setBookPrice1(price1);
        
        System.out.println("Book Details");
        System.out.println("Book Title :"+obj.getBookName());
        System.out.println("Book Price :"+obj.getBookPrice());
        System.out.println("Book Title :"+obj.getBookName1());
        System.out.println("Book Price :"+obj.getBookPrice1());
	}
}
