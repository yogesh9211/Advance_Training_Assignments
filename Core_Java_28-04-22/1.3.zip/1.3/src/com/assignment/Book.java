package com.assignment;

public class Book {

	  private String bookName;
	    private int bookPrice;
	    private String bookName1;
	    public String getBookName1() {
			return bookName1;
		}

		public void setBookName1(String bookName1) {
			this.bookName1 = bookName1;
		}

		public int getBookPrice1() {
			return bookPrice1;
		}

		public void setBookPrice1(int bookPrice1) {
			this.bookPrice1 = bookPrice1;
		}

		private int bookPrice1;
	    
	    
	     public void setBookName(String bookName)
	    {
	        this.bookName=bookName;
	    }
	    
	    public String getBookName()
	    {
	        return this.bookName;
	    }
	    
	    public void setBookPrice(int bookPrice)
	    {
	        this.bookPrice=bookPrice;
	    }
	    
	    public int getBookPrice()
	    {
	        return this.bookPrice;
	    }
}
