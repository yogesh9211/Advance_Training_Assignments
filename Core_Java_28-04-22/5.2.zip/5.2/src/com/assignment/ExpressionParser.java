package com.assignment;

public class ExpressionParser {

	public static void main(String[] args) {

		String txt= (" 23  +  45  -  (  343  /  12  ) ");
		String[] a=txt.split("\\\s");
		
		for(String a1:a){ 
			
			System.out.println(a1); 
			
		}
	}
}
